    # slot value for lex bot 
ORIGINAL_VALUE = 0
TOP_RESOLUTION = 1

    #slot user change value: day, time and problem 
SLOT_CONFIG = {
    'day':              {'type': ORIGINAL_VALUE, 'remember': True}, 
    'time':             {'type': ORIGINAL_VALUE, 'remember': True},
    'problem':          {'type': TOP_RESOLUTION, 'remember': True,  'error': 'I didn\'t understand "{}".'},
}

class SlotError(Exception):
    pass

